from tkinter import *
from tkinter import ttk


ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()
ventana = Tk ()


ventana.title("Desplegable")

ventana.geometry("600x700")

ventana.mainloop()






